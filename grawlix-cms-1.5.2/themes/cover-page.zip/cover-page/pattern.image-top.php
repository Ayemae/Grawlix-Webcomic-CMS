<section class="pattern-image-top" id="{id}">
	<figure><a href="{link}"><img src="{image}" alt="{title}"/></a></figure>
	<h3>{title}</h3>
	<div class="content">
		{content}
	</div>
</section>

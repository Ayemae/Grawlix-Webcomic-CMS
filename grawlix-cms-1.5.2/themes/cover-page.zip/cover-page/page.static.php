	<?=snippet('meta-head')?>
<!-- GRAWLIX TEMPLATE: This comes from page.static -->
<body>
		<main>
			<article class="container">
				<?=show('page_content')?>
			</article>
		</main>
</body>
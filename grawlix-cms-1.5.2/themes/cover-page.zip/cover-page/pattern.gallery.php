<a href="{image}" data-lightbox="gallery" data-title="{title}"><div style="background:url('{image}');background-position: center center;width:100px;height:100px;margin:10px;" alt="{title}"></div></a>

	<footer>
		<h5><?=show('site_name')?></h5>
		<a title="Follow RSS" href="<?=show('rss')?>">RSS feed</a>
		<p>Updates <?=show('publish_frequency')?></p>
		<p><?=show('copyright')?></p>
		<p class="grawlix">Powered by <a href="http://getgrawlix.com">Grawlix</a>.</p>
	</footer>
</body>
</html>

<section id="{id}">
	<figure><a href="{link}"><img src="{image}" alt="{image}"/></a></figure>
	{text}
	<br class="clearfix"/>
</section>

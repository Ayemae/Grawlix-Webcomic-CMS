<section id="{id}">
	<header><a href="{link}">{heading}</a></header>
	<figure><a href="{link}"><img src="{image}" alt="{image}"/></a></figure>
	<br class="clearfix"/>
</section>

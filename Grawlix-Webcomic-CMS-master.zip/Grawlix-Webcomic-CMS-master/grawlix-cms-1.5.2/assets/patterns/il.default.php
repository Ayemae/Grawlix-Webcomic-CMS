<section id="{id}">
	<figure><a href="{link}"><img src="{image}" alt="{image}"/></a></figure>
	<br class="clearfix"/>
</section>

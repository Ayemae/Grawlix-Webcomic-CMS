<section id="{id}">
	<figure><img src="{image}" alt="{image}"/></figure>
	<header>{heading}</header>
	{text}
	<br class="clearfix"/>
</section>

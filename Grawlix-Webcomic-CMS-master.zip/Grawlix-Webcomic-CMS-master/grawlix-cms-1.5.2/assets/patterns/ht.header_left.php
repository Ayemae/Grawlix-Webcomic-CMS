<section id="{id}" class="alongside">
	<header>{heading}</header>
	<div>{text}</div>
	<br class="clearfix"/>
</section>

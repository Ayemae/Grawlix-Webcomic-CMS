<section id="{id}" class="fullheader">
	<header>{heading}</header>
	<div>{text}</div>
	<figure><img src="{image}" alt="{image}"/></figure>
	<br class="clearfix"/>
	<br class="clearfix"/>
</section>

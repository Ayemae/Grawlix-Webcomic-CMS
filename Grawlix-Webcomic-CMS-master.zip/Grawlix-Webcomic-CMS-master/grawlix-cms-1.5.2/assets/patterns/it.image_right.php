<section id="{id}" class="samewidth">
	<div>{text}</div>
	<figure><img src="{image}" alt="{image}"/></figure>
	<br class="clearfix"/>
</section>

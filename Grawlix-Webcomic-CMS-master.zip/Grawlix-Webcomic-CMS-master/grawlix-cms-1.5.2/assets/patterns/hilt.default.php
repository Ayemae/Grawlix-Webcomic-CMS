<section id="{id}">
	<figure><a href="{link}"><img src="{image}" alt="{image}"/></a></figure>
	<header><a href="{link}">{heading}</a></header>
	<div>{text}</div>
	<br class="clearfix"/>
</section>

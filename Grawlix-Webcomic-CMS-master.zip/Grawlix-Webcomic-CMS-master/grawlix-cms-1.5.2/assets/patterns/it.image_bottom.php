<section id="{id}">
	{text}
	<figure><img src="{image}" alt="{image}"/></figure>
	<br class="clearfix"/>
</section>

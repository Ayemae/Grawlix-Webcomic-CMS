<section id="{id}">
	<header>{heading}</header>
	{text}
	<br class="clearfix"/>
</section>

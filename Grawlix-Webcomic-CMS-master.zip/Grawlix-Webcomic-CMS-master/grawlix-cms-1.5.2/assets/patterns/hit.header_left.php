<section id="{id}" class="samewidth">
	<div>
		<header>{heading}</header>
		{text}
	</div>
	<figure><img src="{image}" alt="{image}"/></figure>
	<br class="clearfix"/>
</section>

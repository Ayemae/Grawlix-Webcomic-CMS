<section id="{id}" class="fullheader transpose">
	<header><a href="{link}">{heading}</a></header>
	<div>{text}</div>
	<figure><a href="{link}"><img src="{image}" alt="{image}"/></a></figure>
	<br class="clearfix"/>
</section>

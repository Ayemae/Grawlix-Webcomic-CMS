<section id="{id}">
	<header>{heading}</header>
	<figure><img src="{image}" alt="{image}"/></figure>
	{text}
	<br class="clearfix"/>
</section>

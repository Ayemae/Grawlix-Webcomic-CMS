<section id="{id}" class="samewidth">
	<div>
		<header><a href="{link}">{heading}</a></header>
		{text}
	</div>
	<figure><a href="{link}"><img src="{image}" alt="{image}"/></a></figure>
	<br class="clearfix"/>
</section>

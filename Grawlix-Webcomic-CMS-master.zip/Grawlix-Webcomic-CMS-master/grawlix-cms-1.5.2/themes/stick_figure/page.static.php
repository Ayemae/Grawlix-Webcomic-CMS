	<?=snippet('header')?>
<!-- GRAWLIX TEMPLATE: This comes from page.static -->
		<main>
			<article>
				<?=show('page_content')?>
			</article>
			<br class="clearfix"/>
		</main>
	<?=snippet('footer')?>

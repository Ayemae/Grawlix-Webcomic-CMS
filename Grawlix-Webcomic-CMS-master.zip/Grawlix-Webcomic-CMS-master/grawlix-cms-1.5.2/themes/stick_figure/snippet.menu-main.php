<!-- GRAWLIX TEMPLATE: This comes from snippet.main-menu -->

<nav role="navigation" class="container">
	<ul class="button-group">
		<?=show('menu')?>
	</ul>
</nav>

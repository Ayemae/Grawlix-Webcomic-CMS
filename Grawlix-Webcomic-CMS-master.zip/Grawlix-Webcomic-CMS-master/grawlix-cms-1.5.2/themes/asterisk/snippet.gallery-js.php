<script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="/lightbox2-master/src/js/lightbox.js"></script>
<link href="/lightbox2-master/src/css/lightbox.css" rel="stylesheet"/>

<section class="pattern-no-image" id="{id}">
	<h3>{title}</h3>
	<div class="content">
		{content}
	</div>
</section>

<!-- GRAWLIX TEMPLATE: This comes from snippet.footer -->

		<footer class="page__footer">
				<!-- Edit this with fields in the admin panel or write your own copyright statement here. -->
				<?=show('copyright')?> by <?=show('artist_name')?> &#8253; Updates <?=show('publish_frequency')?> &#8253; Powered by <a href="http://www.getgrawlix.com/">The Grawlix CMS</a>
			</div>

				<?=show_ad('slot-1') ?>
		</footer>
	</div><!-- end .page -->
	<?/* =snippet('googleanalytics') */?>
	<?/* =snippet('project-wonderful') */?>
	</body>
</html>
